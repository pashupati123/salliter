import os
import json
data=json.loads(open('/Users/pverma/desktop/tes/data.json').read())
print(data)