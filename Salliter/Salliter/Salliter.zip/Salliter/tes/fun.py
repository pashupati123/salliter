import os

def call(b):
	print("function_called")
	print(b)
	a=[]
	print(a[2])

